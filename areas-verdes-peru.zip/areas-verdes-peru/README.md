# Normas de Áreas Verdes del Perú

Buscador web de normas peruanas sobre **áreas verdes, parques, arbolado y espacios públicos**.
Es una página estática (HTML + JavaScript): no necesita servidor ni instalación y se puede
publicar gratis con GitHub Pages.

## Qué hace

- Búsqueda de texto libre por título, número, resumen y palabras clave (ignora tildes y mayúsculas;
  ej.: `areas verdes`, `habilitación urbana`, `31199`).
- Filtros por tema, por tipo de norma (Ley, Decreto Supremo, Guía técnica, Ordenanza…) y por
  "solo verificadas".
- Cada resultado enlaza a una fuente oficial o de consulta.
- Los filtros quedan en la URL, así puedes compartir una búsqueda (`?q=parques&tema=diseno`).

## Temas

| Tema | Contenido |
|---|---|
| Espacios públicos | Protección de parques, plazas y áreas verdes (Ley 31199 y su reglamento) |
| Planificación urbana | Desarrollo urbano sostenible, planes y zonificación |
| Diseño y habilitación | Aportes para recreación pública, RNE, guías de diseño de parques |
| Gestión municipal | Competencias municipales y ordenanzas distritales/provinciales |

## Usarlo

Abre `index.html` en el navegador. Para correr las pruebas (requiere Node.js):

```bash
node tests/search.test.js
```

## Publicarlo en GitHub

1. Crea un repositorio nuevo en https://github.com/new (por ejemplo `areas-verdes-peru`).
2. Desde esta carpeta:

   ```bash
   git init
   git add .
   git commit -m "Buscador de normas de áreas verdes del Perú"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/areas-verdes-peru.git
   git push -u origin main
   ```

3. En el repositorio: **Settings → Pages → Deploy from a branch → `main` / `(root)`**.

## Estructura

```
index.html            Interfaz
js/search.js          Lógica de búsqueda (sin dependencias)
data/normas.js        Base de datos de normas
tests/search.test.js  Pruebas
```

## Agregar o corregir normas

Edita `data/normas.js` y agrega un objeto como este:

```js
{
  id: "ord-000-2025-md-ejemplo",   // único
  temas: ["municipal"],            // espacios | planificacion | diseno | municipal
  tipo: "Ordenanza municipal",
  numero: "000-2025-MD-EJEMPLO",
  titulo: "Título oficial",
  resumen: "Qué regula, en una o dos frases.",
  fecha: "2025-01-31",             // AAAA-MM-DD (o solo año / año-mes)
  entidad: "Municipalidad Distrital de Ejemplo",
  estado: "Vigente",
  verificado: true,                // true solo si lo contrastaste con una fuente oficial
  url: "https://...",
  palabras: ["términos", "relacionados"]
}
```

Luego ejecuta `node tests/search.test.js` para validar los campos.

## Importante

- La base inicial es una **selección** de normas nacionales y un ejemplo de ordenanza distrital.
  Cada municipalidad tiene sus propias ordenanzas sobre áreas verdes y arbolado: no están todas aquí.
- Las normas marcadas **"Confirmar vigencia"** se cargaron por conocimiento general. Verifícalas antes
  de citarlas. Las fechas de algunas normas verificadas figuran solo con año o mes porque la fuente
  consultada no las indicaba.
- El Reglamento Nacional de Edificaciones se modifica con frecuencia: confirma siempre el texto vigente.
- Este proyecto no constituye asesoría legal.

## Licencia

MIT (ver `LICENSE`).
