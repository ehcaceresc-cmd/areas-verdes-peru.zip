// Ejecutar con: node tests/search.test.js
const assert = require("assert");
const NORMAS = require("../data/normas.js");
const { buscar, normalizar } = require("../js/search.js");

const TEMAS = ["espacios", "planificacion", "diseno", "municipal"];
let pruebas = 0;
function prueba(nombre, fn) {
  fn();
  pruebas++;
  console.log("ok -", nombre);
}

prueba("normalizar quita tildes y mayúsculas", () => {
  assert.strictEqual(normalizar("  Áreas  VERDES "), "areas verdes");
});

prueba("ids únicos y campos obligatorios", () => {
  const ids = new Set();
  for (const n of NORMAS) {
    assert(!ids.has(n.id), "id repetido: " + n.id);
    ids.add(n.id);
    for (const campo of ["id", "temas", "tipo", "numero", "titulo", "resumen", "entidad", "estado", "url"]) {
      assert(n[campo], `falta ${campo} en ${n.id}`);
    }
    assert(n.temas.length > 0 && n.temas.every((t) => TEMAS.includes(t)), "tema inválido en " + n.id);
    assert(typeof n.verificado === "boolean", "verificado debe ser booleano en " + n.id);
    assert(/^https:\/\//.test(n.url), "url inválida en " + n.id);
  }
});

prueba("los cuatro temas tienen normas", () => {
  for (const tema of TEMAS) assert(buscar(NORMAS, { tema }).length > 0, "sin normas de " + tema);
});

prueba("'areas verdes' encuentra el reglamento de espacios públicos", () => {
  const r = buscar(NORMAS, { texto: "areas verdes" });
  assert(r.some((n) => n.id === "ds-001-2023-vivienda"));
});

prueba("búsqueda por número de norma", () => {
  assert.strictEqual(buscar(NORMAS, { texto: "31199" })[0].id, "ley-31199");
});

prueba("búsqueda con tildes y sin tildes da lo mismo", () => {
  const a = buscar(NORMAS, { texto: "habilitación urbana" }).map((n) => n.id);
  const b = buscar(NORMAS, { texto: "habilitacion urbana" }).map((n) => n.id);
  assert.deepStrictEqual(a, b);
  assert(a.includes("ley-29090"));
});

prueba("filtro por tema excluye otros temas", () => {
  const r = buscar(NORMAS, { tema: "planificacion" });
  assert(r.every((n) => n.temas.includes("planificacion")));
  assert(!r.some((n) => n.id === "ord-14-2023-mdlp"));
});

prueba("consulta sin coincidencias devuelve vacío", () => {
  assert.strictEqual(buscar(NORMAS, { texto: "zzzxxyy" }).length, 0);
});

prueba("solo verificadas filtra correctamente", () => {
  const r = buscar(NORMAS, { soloVerificadas: true });
  assert(r.length > 0 && r.every((n) => n.verificado));
});

prueba("tema + texto se combinan", () => {
  const r = buscar(NORMAS, { tema: "municipal", texto: "ordenanza" });
  assert(r.length > 0 && r.every((n) => n.temas.includes("municipal")));
});

console.log(`\n${pruebas} pruebas pasaron`);
