// Lógica de búsqueda (sin dependencias). Funciona en el navegador y en Node.
(function (root) {
  "use strict";

  // Minúsculas y sin tildes, para que "atmosférica" encuentre "atmosferica".
  function normalizar(texto) {
    return String(texto || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function tokens(consulta) {
    return normalizar(consulta).split(" ").filter(Boolean);
  }

  // Puntaje de una norma para una consulta. 0 = no coincide.
  // Todas las palabras de la consulta deben aparecer en algún campo (AND).
  function puntuar(norma, palabras) {
    if (!palabras.length) return 1;
    const campos = [
      { texto: normalizar(norma.numero), peso: 8 },
      { texto: normalizar(norma.titulo), peso: 5 },
      { texto: normalizar((norma.palabras || []).join(" ")), peso: 4 },
      { texto: normalizar(norma.tipo + " " + norma.entidad), peso: 2 },
      { texto: normalizar(norma.resumen), peso: 1 }
    ];
    let total = 0;
    for (const palabra of palabras) {
      let mejor = 0;
      for (const c of campos) {
        if (c.texto.includes(palabra)) mejor = Math.max(mejor, c.peso);
      }
      if (mejor === 0) return 0;
      total += mejor;
    }
    return total;
  }

  // filtros: { texto, tema, tipo, soloVerificadas }
  function buscar(normas, filtros) {
    const f = filtros || {};
    const palabras = tokens(f.texto);
    return normas
      .filter((n) => !f.tema || n.temas.includes(f.tema))
      .filter((n) => !f.tipo || n.tipo === f.tipo)
      .filter((n) => !f.soloVerificadas || n.verificado)
      .map((n) => ({ norma: n, puntaje: puntuar(n, palabras) }))
      .filter((r) => r.puntaje > 0)
      .sort((a, b) =>
        b.puntaje - a.puntaje ||
        String(b.norma.fecha).localeCompare(String(a.norma.fecha))
      )
      .map((r) => r.norma);
  }

  const api = { normalizar, tokens, puntuar, buscar };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.Buscador = api;
})(typeof window !== "undefined" ? window : globalThis);
